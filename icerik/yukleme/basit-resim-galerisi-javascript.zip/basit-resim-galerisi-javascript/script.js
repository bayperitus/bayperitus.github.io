var toplam = 0;
var dizi = ["resim-0.jpg", "resim-1.jpg", "resim-2.jpg", 
            "resim-3.jpg", "resim-4.jpg", "resim-5.jpg"];


function ileriGeri() {
	document.getElementById('onceki').onclick = function() {

		var resim = document.getElementById("resim");
		toplam = toplam - 1;

		if(toplam < 0) {
			toplam = 0
			resim.src = "images/" + dizi[0];		
		} else {
			resim.src = "images/" + dizi[toplam];
		}
	};

	document.getElementById('sonraki').onclick = function() {

		var resim = document.getElementById("resim");
		toplam = toplam + 1;

		if(toplam > 5) {
			toplam = 5
			resim.src = "images/" + dizi[5];		
		} else {
			resim.src = "images/" + dizi[toplam];
			resim.style.display = "block";
		}
	};
}